from distutils.core import setup

setup(
    name='Youtube-Uploader-Selenium',
    version='0.1dev',
    packages=['youtube_uploader_selenium',],
    license='MIT',
    long_description=open('README.md').read(),
)